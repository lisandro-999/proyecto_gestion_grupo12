package com.grupo12.listeners;

import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.ExecutionListener;

public class EvaluarViabilidadListener implements ExecutionListener {

    @Override
    public void notify(DelegateExecution execution) {
        // Si no se pasó la variable explícitamente en el mapa inicial, por defecto asumimos 0 cursos activos
        if (!execution.hasVariable("cantidadCursos")) {
            execution.setVariable("cantidadCursos", 0);
        }
    }
}