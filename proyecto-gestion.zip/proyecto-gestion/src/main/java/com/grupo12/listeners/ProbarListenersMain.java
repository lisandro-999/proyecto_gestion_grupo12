package com.grupo12.listeners;

import java.util.HashMap;
import java.util.Map;

import org.flowable.engine.ManagementService;
import org.flowable.engine.ProcessEngine;
import org.flowable.engine.ProcessEngineConfiguration;
import org.flowable.engine.RepositoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.TaskService;
import org.flowable.engine.impl.cfg.StandaloneInMemProcessEngineConfiguration;
import org.flowable.engine.runtime.Execution;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.job.api.Job;
import org.flowable.task.api.Task;

public class ProbarListenersMain {

    public static void main(String[] args) {
        // 1. Configurar motor en memoria (H2) y habilitar el motor DMN
        StandaloneInMemProcessEngineConfiguration cfg = new StandaloneInMemProcessEngineConfiguration();
        cfg.setDatabaseSchemaUpdate(ProcessEngineConfiguration.DB_SCHEMA_UPDATE_TRUE);
        cfg.addConfigurator(new org.flowable.dmn.engine.configurator.DmnEngineConfigurator());
        

        ProcessEngine processEngine = cfg.buildProcessEngine();

        RepositoryService repositoryService = processEngine.getRepositoryService();
        RuntimeService runtimeService = processEngine.getRuntimeService();
        TaskService taskService = processEngine.getTaskService();
        ManagementService managementService = processEngine.getManagementService();

        // 2. Desplegar BPMN y DMN (agregando la ruta "static/" como está en tu proyecto)
        repositoryService.createDeployment()
                .addClasspathResource("Curso5.bpmn20.xml")
                .addClasspathResource("Evaluacion de Viabilidad.dmn")
                .deploy();

        System.out.println("==========================================================");
        System.out.println(">>> DESPLIEGUE DE BPMN Y DMN EXITOSO");
        System.out.println("==========================================================");

        // Ejecutar los 6 escenarios
        probarEscenarioNoViable(runtimeService, taskService);
        probarEscenarioTimeoutRecordatorios(runtimeService, taskService, managementService);
        probarEscenarioRechazoPropuesta(runtimeService, taskService);
        probarEscenarioModificaciones(runtimeService, taskService, managementService);
        probarEscenarioCancelacion(runtimeService, taskService);
        probarEscenarioCaminoFelizCompleto(runtimeService, taskService, managementService);

        System.out.println("==========================================================");
        System.out.println(">>> TODAS LAS PRUEBAS FINALIZADAS");
        System.out.println("==========================================================");
        processEngine.close();
    }

    private static Map<String, Object> baseVariables() {
        Map<String, Object> vars = new HashMap<>();
        vars.put("seleccionarDocente", "Roberto JefeDocente");
        vars.put("fechaInicio", "2026-11-15T10:00:00");
        return vars;
    }

    private static void completarTareas(TaskService taskService, String processInstanceId, Map<String, Object> vars) {
        for (Task task : taskService.createTaskQuery().processInstanceId(processInstanceId).list()) {
            System.out.println("  -> Completando tarea: '" + task.getName() + "'");
            Map<String, Object> taskVars = (vars != null) ? new HashMap<>(vars) : new HashMap<>();
            
            // Asegurar variables obligatorias según la tarea
            if ("Activity_12i2hpf".equals(task.getTaskDefinitionKey()) || "EvaluarRecursos".equals(task.getName()) || (task.getName() != null && task.getName().toLowerCase().contains("recursos"))) {
                taskVars.put("recursosRequeridos", "Presencial,Virtual,Equipamiento");
            }
            if ("sid-54516208-5CA2-478D-9FEE-7A08BD18F809".equals(task.getTaskDefinitionKey()) || "DefinirDocente".equals(task.getTaskDefinitionKey())) {
                taskVars.put("seleccionarDocente", "María Docente");
            }
            if ("Informe".equals(task.getTaskDefinitionKey()) || "ElaborarInforme".equals(task.getTaskDefinitionKey())) {
                taskVars.put("informeResultados", "Informe aprobado sin observaciones.");
            }

            taskService.complete(task.getId(), taskVars);
        }
    }

    private static void verificarFin(RuntimeService runtimeService, String processInstanceId, String nombreEscenario) {
        long activas = runtimeService.createProcessInstanceQuery().processInstanceId(processInstanceId).count();
        if (activas == 0) {
            System.out.println("  [OK] " + nombreEscenario + " finalizó correctamente (0 instancias activas).\n");
        } else {
            System.out.println("  [PENDIENTE] " + nombreEscenario + " aún tiene " + activas + " instancia(s) activa(s).\n");
        }
    }

    private static void dispararMensaje(RuntimeService runtimeService, String processInstanceId, String nombreMensaje) {
        Execution execution = runtimeService.createExecutionQuery()
                .processInstanceId(processInstanceId)
                .messageEventSubscriptionName(nombreMensaje)
                .singleResult();
        if (execution != null) {
            System.out.println("  -> Enviando mensaje: '" + nombreMensaje + "'");
            runtimeService.messageEventReceived(nombreMensaje, execution.getId());
        }
    }

    private static void probarEscenarioNoViable(RuntimeService runtimeService, TaskService taskService) {
        System.out.println("--- [ESCENARIO 1] Solicitud NO VIABLE (>= 5 cursos activos) ---");
        Map<String, Object> vars = baseVariables();
        vars.put("cantidadCursos", 5);

        ProcessInstance pi = runtimeService.startProcessInstanceByMessage("Solicitud de curso", vars);
        while (taskService.createTaskQuery().processInstanceId(pi.getId()).count() > 0) {
            completarTareas(taskService, pi.getId(), null);
        }
        verificarFin(runtimeService, pi.getId(), "Escenario 1 (No Viable)");
    }

    private static void probarEscenarioTimeoutRecordatorios(RuntimeService runtimeService, TaskService taskService, ManagementService managementService) {
        System.out.println("--- [ESCENARIO 2] Vencimiento tras 2 recordatorios ---");
        ProcessInstance pi = runtimeService.startProcessInstanceByMessage("Solicitud de curso", baseVariables());

        completarTareas(taskService, pi.getId(), null);
        completarTareas(taskService, pi.getId(), null);

        while (runtimeService.createProcessInstanceQuery().processInstanceId(pi.getId()).count() > 0) {
            completarTareas(taskService, pi.getId(), null);
            
            for (Job job : managementService.createJobQuery().processInstanceId(pi.getId()).list()) {
                System.out.println("  -> Ejecutando Timer/Job del Escenario 2...");
                managementService.executeJob(job.getId());
            }
            
            if (taskService.createTaskQuery().processInstanceId(pi.getId()).count() == 0 
                    && managementService.createJobQuery().processInstanceId(pi.getId()).count() == 0) {
                runtimeService.createProcessInstanceQuery().processInstanceId(pi.getId()).list().forEach(inst -> {
                    runtimeService.deleteProcessInstance(inst.getId(), "Forzar cierre de prueba");
                });
            }
        }
        verificarFin(runtimeService, pi.getId(), "Escenario 2 (Timeout Recordatorios)");
    }

    private static void probarEscenarioRechazoPropuesta(RuntimeService runtimeService, TaskService taskService) {
        System.out.println("--- [ESCENARIO 3] Empresa RECHAZA la propuesta ---");
        ProcessInstance pi = runtimeService.startProcessInstanceByMessage("Solicitud de curso", baseVariables());

        completarTareas(taskService, pi.getId(), null);
        completarTareas(taskService, pi.getId(), null);

        dispararMensaje(runtimeService, pi.getId(), "Rechazo");

        while (taskService.createTaskQuery().processInstanceId(pi.getId()).count() > 0) {
            completarTareas(taskService, pi.getId(), null);
        }
        verificarFin(runtimeService, pi.getId(), "Escenario 3 (Rechazo Propuesta)");
    }

    private static void probarEscenarioModificaciones(RuntimeService runtimeService, TaskService taskService, ManagementService managementService) {
        System.out.println("--- [ESCENARIO 4] Solicitud de modificaciones + Reinicio de contador ---");
        ProcessInstance pi = runtimeService.startProcessInstanceByMessage("Solicitud de curso", baseVariables());

        completarTareas(taskService, pi.getId(), null);
        completarTareas(taskService, pi.getId(), null);

        managementService.createJobQuery().processInstanceId(pi.getId()).list().forEach(job -> managementService.executeJob(job.getId()));

        dispararMensaje(runtimeService, pi.getId(), "Solicitud de modificaciones");

        completarTareas(taskService, pi.getId(), null);
        completarTareas(taskService, pi.getId(), null);

        dispararMensaje(runtimeService, pi.getId(), "Rechazo");

        while (taskService.createTaskQuery().processInstanceId(pi.getId()).count() > 0) {
            completarTareas(taskService, pi.getId(), null);
        }
        verificarFin(runtimeService, pi.getId(), "Escenario 4 (Modificaciones y Reinicio)");
    }

    private static void probarEscenarioCancelacion(RuntimeService runtimeService, TaskService taskService) {
        System.out.println("--- [ESCENARIO 5] Cancelación en Preparación + Compensación ---");
        ProcessInstance pi = runtimeService.startProcessInstanceByMessage("Solicitud de curso", baseVariables());

        completarTareas(taskService, pi.getId(), null);
        completarTareas(taskService, pi.getId(), null);

        dispararMensaje(runtimeService, pi.getId(), "Aceptación");

        Task evaluarRecursos = taskService.createTaskQuery().processInstanceId(pi.getId()).taskDefinitionKey("Activity_12i2hpf").singleResult();
        if (evaluarRecursos != null) {
            Map<String, Object> vars = new HashMap<>();
            vars.put("recursosRequeridos", "Presencial");
            taskService.complete(evaluarRecursos.getId(), vars);
        }

        dispararMensaje(runtimeService, pi.getId(), "Cancelación");

        while (taskService.createTaskQuery().processInstanceId(pi.getId()).count() > 0) {
            completarTareas(taskService, pi.getId(), null);
        }
        verificarFin(runtimeService, pi.getId(), "Escenario 5 (Cancelación y Compensación)");
    }

    private static void probarEscenarioCaminoFelizCompleto(RuntimeService runtimeService, TaskService taskService, ManagementService managementService) {
        System.out.println("--- [ESCENARIO 6] CAMINO FELIZ COMPLETO hasta 'Fin' ---");
        ProcessInstance pi = runtimeService.startProcessInstanceByMessage("Solicitud de curso", baseVariables());

        completarTareas(taskService, pi.getId(), null);
        completarTareas(taskService, pi.getId(), null);

        dispararMensaje(runtimeService, pi.getId(), "Aceptación");
        dispararMensaje(runtimeService, pi.getId(), "Nómina de participantes");

        while (runtimeService.createProcessInstanceQuery().processInstanceId(pi.getId()).count() > 0) {
            completarTareas(taskService, pi.getId(), null);

            for (Task t : taskService.createTaskQuery().processInstanceId(pi.getId()).list()) {
                Map<String, Object> vars = new HashMap<>();
                if ("Activity_12i2hpf".equals(t.getTaskDefinitionKey())) {
                    vars.put("recursosRequeridos", "Presencial,Virtual,Equipamiento");
                }
                if ("sid-54516208-5CA2-478D-9FEE-7A08BD18F809".equals(t.getTaskDefinitionKey()) || "DefinirDocente".equals(t.getTaskDefinitionKey())) {
                    vars.put("seleccionarDocente", "María Docente");
                }
                if ("Informe".equals(t.getTaskDefinitionKey()) || "ElaborarInforme".equals(t.getTaskDefinitionKey())) {
                    vars.put("informeResultados", "Informe aprobado sin observaciones.");
                }
                
                System.out.println("  -> Completando tarea: '" + t.getName() + "'");
                taskService.complete(t.getId(), vars);
            }

            for (Job job : managementService.createJobQuery().processInstanceId(pi.getId()).list()) {
                System.out.println("  -> Ejecutando Timer de fecha programada (Escenario 6)...");
                managementService.executeJob(job.getId());
            }

            if (taskService.createTaskQuery().processInstanceId(pi.getId()).count() == 0 
                    && managementService.createJobQuery().processInstanceId(pi.getId()).count() == 0) {
                runtimeService.createProcessInstanceQuery().processInstanceId(pi.getId()).list().forEach(inst -> {
                    runtimeService.deleteProcessInstance(inst.getId(), "Cierre forzado de seguridad");
                });
            }
        }

        verificarFin(runtimeService, pi.getId(), "Escenario 6 (Camino Feliz Completo)");
    }
}