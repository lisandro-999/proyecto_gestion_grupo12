package com.grupo12.listeners;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.ExecutionListener;

public class ActualizarEstadoCursoListener implements ExecutionListener {

    private static final String DB_URL = "jdbc:postgresql://postgres:5432/flowable";
    private static final String DB_USER = "postgres";
    private static final String DB_PASS = "password";

    @Override
    public void notify(DelegateExecution execution) {
        Object rawResultado = execution.getVariable("resultadoCurso");
        String estadoNormalizado = normalizarEstado(rawResultado);
        String processInstanceId = execution.getProcessInstanceId();

        System.out.println(">>> [Flowable Listener] Finalizando instancia " + processInstanceId
                + " | resultadoCurso=" + rawResultado + " -> estado=" + estadoNormalizado);

        try {
            Class.forName("org.postgresql.Driver");
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
                 PreparedStatement ps = conn.prepareStatement(
                         "UPDATE curso SET estado = ? WHERE process_instance_id = ?")) {
                ps.setString(1, estadoNormalizado);
                ps.setString(2, processInstanceId);
                int filas = ps.executeUpdate();
                System.out.println(">>> [Flowable Listener] Filas actualizadas en curso: " + filas);
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println(">>> [Flowable Listener] Error actualizando estado en PostgreSQL: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private String normalizarEstado(Object raw) {
        if (raw == null) {
            return "CERRADO";
        }
        String val = raw.toString().trim().toUpperCase();
        switch (val) {
            case "FINALIZADO":
                return "FINALIZADO";
            case "CANCELADO":
                return "CANCELADO";
            case "RECHAZADO":
            case "RECHAZADA":
                return "RECHAZADO";
            case "CERRADO_SIN_RESPUESTA":
            case "SIN_RESPUESTA":
            case "PLAZOS_VENCIDOS":
                return "CERRADO_SIN_RESPUESTA";
            case "NO_VIABLE":
            case "NO VIABLE":
                return "NO_VIABLE";
            default:
                return val;
        }
    }
}