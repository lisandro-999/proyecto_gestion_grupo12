package com.grupo12.controller;

import com.grupo12.service.FlowableClientService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class SolicitudController {

    private static final String DB_URL = "jdbc:postgresql://localhost:5432/flowable"; 
    private static final String DB_USER = "postgres";
    private static final String DB_PASS = "password";

    @PostMapping("/solicitudes")
    public ResponseEntity<Object> recibirSolicitud(@RequestBody SolicitudDTO dto) {
        Map<String, Object> respuesta = new HashMap<>();
        
        try {
            Class.forName("org.postgresql.Driver");
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
                conn.setAutoCommit(false);

                // 2. Insertar o buscar empresa
                int empresaId = 0;
                String sqlEmpresa = "INSERT INTO empresa (cuit, nombre, email_contacto, telefono_contacto) " +
                                    "VALUES (?, ?, ?, ?) ON CONFLICT (cuit) DO UPDATE " +
                                    "SET nombre = EXCLUDED.nombre, email_contacto = EXCLUDED.email_contacto, " +
                                    "telefono_contacto = EXCLUDED.telefono_contacto RETURNING id";
                
                try (PreparedStatement psEmpresa = conn.prepareStatement(sqlEmpresa)) {
                    psEmpresa.setString(1, dto.getCuit());
                    psEmpresa.setString(2, dto.getNombreEmpresa());
                    psEmpresa.setString(3, dto.getEmailContacto());
                    psEmpresa.setString(4, dto.getTelefonoContacto());
                    try (ResultSet rs = psEmpresa.executeQuery()) {
                        if (rs.next()) empresaId = rs.getInt(1);
                    }
                }

                // 3. Insertar curso con todos los datos del formulario
                int cursoId = 0;
                String sqlCurso = "INSERT INTO curso (empresa_id, nombre, descripcion, cantidad_participantes, fechas_preferidas, estado) " +
                                  "VALUES (?, ?, ?, ?, ?, 'EN_EVALUACION') RETURNING id";
                try (PreparedStatement psCurso = conn.prepareStatement(sqlCurso)) {
                    psCurso.setInt(1, empresaId);
                    psCurso.setString(2, dto.getTematica());
                    psCurso.setString(3, dto.getDescripcion());
                    psCurso.setInt(4, dto.getCantidadParticipantes());
                    psCurso.setString(5, dto.getFechasPreferidas());
                    try (ResultSet rs = psCurso.executeQuery()) {
                        if (rs.next()) cursoId = rs.getInt(1);
                    }
                }

                // 4. Llamar a Flowable a través del Servicio
                String processInstanceId = FlowableClientService.iniciarInstanciaProceso("curso5", dto.getNombreEmpresa(), true);

                // 5. Actualizar el curso con el ID de Flowable
                String sqlUpdate = "UPDATE curso SET process_instance_id = ? WHERE id = ?";
                try (PreparedStatement psUpdate = conn.prepareStatement(sqlUpdate)) {
                    psUpdate.setString(1, processInstanceId);
                    psUpdate.setInt(2, cursoId);
                    psUpdate.executeUpdate();
                }

                conn.commit();

                respuesta.put("status", "success");
                respuesta.put("cursoId", cursoId);
                respuesta.put("processInstanceId", processInstanceId);
                return ResponseEntity.status(HttpStatus.CREATED).body(respuesta);
            }

        } catch (Exception e) {
            e.printStackTrace();
            respuesta.put("status", "error");
            respuesta.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(respuesta);
        }
    }

    public static class SolicitudDTO {
        private String cuit;
        private String nombreEmpresa;
        private String emailContacto;
        private String telefonoContacto;
        private String tematica;
        private String descripcion;
        private int cantidadParticipantes;
        private String fechasPreferidas;

        public String getCuit() { return cuit; }
        public void setCuit(String cuit) { this.cuit = cuit; }
        public String getNombreEmpresa() { return nombreEmpresa; }
        public void setNombreEmpresa(String nombreEmpresa) { this.nombreEmpresa = nombreEmpresa; }
        public String getEmailContacto() { return emailContacto; }
        public void setEmailContacto(String emailContacto) { this.emailContacto = emailContacto; }
        public String getTelefonoContacto() { return telefonoContacto; }
        public void setTelefonoContacto(String telefonoContacto) { this.telefonoContacto = telefonoContacto; }
        public String getTematica() { return tematica; }
        public void setTematica(String tematica) { this.tematica = tematica; }
        public String getDescripcion() { return descripcion; }
        public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
        public int getCantidadParticipantes() { return cantidadParticipantes; }
        public void setCantidadParticipantes(int cantidadParticipantes) { this.cantidadParticipantes = cantidadParticipantes; }
        public String getFechasPreferidas() { return fechasPreferidas; }
        public void setFechasPreferidas(String fechasPreferidas) { this.fechasPreferidas = fechasPreferidas; }
    }
}