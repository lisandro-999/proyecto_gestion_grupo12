package com.grupo12.delegates;

import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.JavaDelegate;

public class ReservarAulaDelegate implements JavaDelegate {

    @Override
    public void execute(DelegateExecution execution) {
        // Lógica de reserva de aula (simulada o contra BD/API)
        System.out.println("Ejecutando reserva automática de aula...");

        // Ejemplo: guardar variable en el proceso
        execution.setVariable("aulaAsignada", "Aula 102 - Pabellón 2");
    }
}