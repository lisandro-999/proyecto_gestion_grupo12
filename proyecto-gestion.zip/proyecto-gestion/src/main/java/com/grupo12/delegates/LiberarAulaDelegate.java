package com.grupo12.delegates;

import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LiberarAulaDelegate implements JavaDelegate {

    private static final Logger logger = LoggerFactory.getLogger(LiberarAulaDelegate.class);

    @Override
    public void execute(DelegateExecution execution) {
        String processInstanceId = execution.getProcessInstanceId();
        
        // Recuperamos el aula que fue asignada durante la ejecución de ReservarAulaDelegate
        Object aulaAsignada = execution.getVariable("aulaAsignada");

        if (aulaAsignada != null && !aulaAsignada.toString().isBlank()) {
            logger.info(">>> [COMPENSACIÓN] Liberando el aula '{}' para la instancia de proceso: {}", 
                        aulaAsignada, processInstanceId);
            
            // Aquí iría la llamada a tu servicio/repositorio JPA si actualizás estado en BD:
            // aulaService.liberarAula(aulaAsignada.toString());

            // Limpiamos/actualizamos las variables en el contexto de Flowable
            execution.removeVariable("aulaAsignada");
            execution.setVariable("aulaLiberada", true);
        } else {
            logger.warn(">>> [COMPENSACIÓN] Se ejecutó LiberarAulaDelegate en instancia {}, pero no había ningún aula asignada.", 
                        processInstanceId);
            execution.setVariable("aulaLiberada", false);
        }
    }
}