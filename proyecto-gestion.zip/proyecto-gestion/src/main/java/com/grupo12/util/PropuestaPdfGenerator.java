package com.grupo12.util;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PropuestaPdfGenerator {

    private static final Path CARPETA_PDF = Paths.get("pdfs-propuestas");

    public static int siguienteVersion(String processInstanceId) throws IOException {
        Files.createDirectories(CARPETA_PDF);
        String prefijo = "propuesta_" + sanitizar(processInstanceId) + "_v";
        int maxVersion = 0;
        Pattern p = Pattern.compile("^" + Pattern.quote(prefijo) + "(\\d+)\\.pdf$");

        try (DirectoryStream<Path> stream = Files.newDirectoryStream(CARPETA_PDF)) {
            for (Path entry : stream) {
                String nombre = entry.getFileName().toString();
                Matcher m = p.matcher(nombre);
                if (m.matches()) {
                    int v = Integer.parseInt(m.group(1));
                    if (v > maxVersion) {
                        maxVersion = v;
                    }
                }
            }
        }
        return maxVersion + 1;
    }

    public static Path resolverArchivoVersion(String processInstanceId, int version) {
        String nombre = "propuesta_" + sanitizar(processInstanceId) + "_v" + version + ".pdf";
        return CARPETA_PDF.resolve(nombre);
    }

    public static String generarPdf(
            String processInstanceId,
            String tipoTarea,
            int version,
            String titulo,
            String programa,
            String presupuesto,
            String observaciones,
            String usuarioAdmin
    ) throws IOException {
        Files.createDirectories(CARPETA_PDF);
        Path destino = resolverArchivoVersion(processInstanceId, version);

        String fecha = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

        List<String> lineas = new ArrayList<>();
        lineas.add("PROPUESTA DE CAPACITACION - VERSION v" + version);
        lineas.add("Fecha de generacion: " + fecha);
        lineas.add("Instancia de proceso: " + nullSafe(processInstanceId));
        lineas.add("Etapa / Tarea: " + nullSafe(tipoTarea));
        lineas.add("Responsable: " + nullSafe(usuarioAdmin));
        lineas.add("------------------------------------------------------------");
        lineas.add("Titulo / Resumen: " + nullSafe(titulo));
        if (presupuesto != null && !presupuesto.isBlank()) {
            lineas.add("Presupuesto estimado: $" + presupuesto.trim());
        }
        lineas.add("Programa / Detalle / Cambios:");
        lineas.addAll(envolverTexto(nullSafe(programa), 72));
        lineas.add("Observaciones:");
        lineas.addAll(envolverTexto(nullSafe(observaciones), 72));

        byte[] pdfBytes = construirPdfBasico(lineas);
        Files.write(destino, pdfBytes);
        return destino.getFileName().toString();
    }

    private static byte[] construirPdfBasico(List<String> lineas) {
        StringBuilder contentStream = new StringBuilder();
        contentStream.append("BT\n");
        contentStream.append("/F1 11 Tf\n");
        contentStream.append("50 760 Td\n");
        contentStream.append("15 TL\n");

        boolean primera = true;
        for (String linea : lineas) {
            String limpia = escaparPdf(sinAcentos(linea));
            if (primera) {
                contentStream.append("(").append(limpia).append(") Tj\n");
                primera = false;
            } else {
                contentStream.append("T* (").append(limpia).append(") Tj\n");
            }
        }
        contentStream.append("ET\n");

        byte[] streamBytes = contentStream.toString().getBytes(StandardCharsets.ISO_8859_1);

        String obj1 = "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n";
        String obj2 = "2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n";
        String obj3 = "3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>\nendobj\n";
        String obj4 = "4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n";
        String obj5Header = "5 0 obj\n<< /Length " + streamBytes.length + " >>\nstream\n";
        String obj5Footer = "\nendstream\nendobj\n";

        List<byte[]> partes = new ArrayList<>();
        List<Integer> offsets = new ArrayList<>();

        String header = "%PDF-1.4\n";
        partes.add(header.getBytes(StandardCharsets.ISO_8859_1));
        int pos = header.length();

        String[] objs = {obj1, obj2, obj3, obj4};
        for (String o : objs) {
            offsets.add(pos);
            byte[] b = o.getBytes(StandardCharsets.ISO_8859_1);
            partes.add(b);
            pos += b.length;
        }

        offsets.add(pos);
        byte[] b5h = obj5Header.getBytes(StandardCharsets.ISO_8859_1);
        byte[] b5f = obj5Footer.getBytes(StandardCharsets.ISO_8859_1);
        partes.add(b5h);
        partes.add(streamBytes);
        partes.add(b5f);
        pos += b5h.length + streamBytes.length + b5f.length;

        int xrefPos = pos;
        StringBuilder xref = new StringBuilder();
        xref.append("xref\n0 ").append(offsets.size() + 1).append("\n");
        xref.append("0000000000 65535 f \n");
        for (int off : offsets) {
            xref.append(String.format("%010d 00000 n \n", off));
        }
        xref.append("trailer\n<< /Size ").append(offsets.size() + 1).append(" /Root 1 0 R >>\n");
        xref.append("startxref\n").append(xrefPos).append("\n%%EOF\n");
        partes.add(xref.toString().getBytes(StandardCharsets.ISO_8859_1));

        int totalLen = 0;
        for (byte[] p : partes) totalLen += p.length;
        byte[] resultado = new byte[totalLen];
        int cursor = 0;
        for (byte[] p : partes) {
            System.arraycopy(p, 0, resultado, cursor, p.length);
            cursor += p.length;
        }
        return resultado;
    }

    private static List<String> envolverTexto(String texto, int anchoMax) {
        List<String> salida = new ArrayList<>();
        String[] parrafos = texto.split("\\r?\\n");
        for (String par : parrafos) {
            if (par.isBlank()) {
                salida.add("");
                continue;
            }
            int idx = 0;
            while (idx < par.length()) {
                int fin = Math.min(idx + anchoMax, par.length());
                salida.add(par.substring(idx, fin));
                idx = fin;
            }
        }
        return salida;
    }

    private static String escaparPdf(String s) {
        return s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)");
    }

    private static String sinAcentos(String s) {
        return s.replace("á", "a").replace("é", "e").replace("í", "i").replace("ó", "o").replace("ú", "u")
                .replace("Á", "A").replace("É", "E").replace("Í", "I").replace("Ó", "O").replace("Ú", "U")
                .replace("ñ", "n").replace("Ñ", "N");
    }

    private static String sanitizar(String s) {
        if (s == null || s.isBlank()) return "sin_instancia";
        return s.replaceAll("[^a-zA-Z0-9._-]", "_");
    }

    private static String nullSafe(String s) {
        return s == null ? "" : s.trim();
    }
}